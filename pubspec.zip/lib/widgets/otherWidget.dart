import 'package:flutter/material.dart';
import 'package:ui_flutter/Pages/Profile.dart';
import 'package:ui_flutter/Pages/SettingPage.dart';
import 'package:ui_flutter/Pages/addPost.dart';
import 'package:ui_flutter/Pages/communityPage.dart';
import 'package:ui_flutter/Pages/feedPage.dart';
import 'package:ui_flutter/Pages/loginSignUpPage.dart';
import 'package:ui_flutter/models/user.dart';
import '../config/themeSettings.dart';

class widgets extends StatelessWidget {
  const widgets({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }

  static BottomNavigationBar bottomNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      // fixedColor:  ThemeClass.appTheme.primaryColor,
      selectedIconTheme: IconThemeData(
        color: ThemeClass.appTheme.primaryColor,
      ),
      unselectedIconTheme: IconThemeData(
        color: ThemeClass.appTheme.primaryColor,
      ),

      // selectedItemColor: ThemeClass.appTheme.primaryColor,
      items: <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Icon(
            Icons.home,
          ),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.group,
          ),
          label: 'community',

        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.add,
          ),
          label: 'Add',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.chat,
          ),
          label: 'Chat',
        ),
        BottomNavigationBarItem(
          icon: Icon(
            Icons.notifications,
          ),
          label: 'Notifications',
        ),
      ],
      onTap: (index) {
        onTapFunction(index, context);
      },
      showUnselectedLabels: false,
      showSelectedLabels: false,

    );
  }

  static onTapFunction(int mode, BuildContext context) {
    switch (mode) {
      case 0:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => feedPage()));
        break;
      case 1:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => communityPage()));
        break;
      case 2:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => addPost()));
        break;
      case 3:
        // Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatPage()));
        break;
      case 4:
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => SettingPage()));
        break;
    }
  }

}
